from django.shortcuts import render, redirect
from subway.models import Subway
from subway.models import Amenities
import json

# from subway.models import Subway

# 편의시설 검색
def show_subway(request):
    select_subway = request.GET.get("select_subway")
    select_station = request.GET.get("select_station")


    # 파라미터가 있는 경우, 검색 결과 화면으로 이동
    if select_subway and select_station:
        # Subway 데이터 전부 가져오기
        # subways = Subway.objects.all()
        # print(subways.subway_line)
        subway_line = select_subway[-1:] + '호선'
        subway_name = select_station
        
        # print(select_station)
        subway = Subway.objects.get(subway_line = subway_line, subway_name = subway_name)
        # print(subway.pk)
        amenities = Amenities.objects.filter(subway_id = subway.pk)
        print(amenities)
        
        # subways = Subway.objects.all()
        context = {
            "subway": subway,
            "amenities" : amenities,
        }
        return render(request, "search_result_subway.html", context)
    # 파라미터가 없는 경우 셀렉트 값을 셋팅
    else:
        pass
        # subways = Subway.objects.get(subway_line = '1호선')
        
        # print(subways)
        # subways = Subway.objects.all().values("subway_line", "subway_name")  # 필요한 필드만 가져오기
        # subways_json = json.dumps(list(subways))  # QuerySet을 JSON 문자열로 변환
        
        
    return render(request, "search_subway.html")

# 통계 확인
def show_statistics(request):
    return render(request, "show_statistics.html")
