from django.db import models

# Create your models here.
class Subway(models.Model):
    subway_sort_id = models.CharField("지하철 분류 아이디", max_length = 50)
    subway_line = models.CharField("노선명", max_length = 50)
    subway_name = models.CharField("역명", max_length = 100)
    waiting_room_extent = models.FloatField("대합실 면적", blank=True)
    platform_extent = models.FloatField("승강장 면적", blank=True)
    num_of_subway_users = models.IntegerField("역 이용자수")
    transfor_number = models.IntegerField("노선 개수")

    def __str__(self):
        return self.subway_line + " " + self.subway_name

class Amenities(models.Model):
    subway = models.ForeignKey(Subway, on_delete=models.CASCADE)
    amenities_name = models.CharField("편의시설명", max_length=100)
    count_number = models.IntegerField("개수")
    def __str__(self):
        return self.amenities_name