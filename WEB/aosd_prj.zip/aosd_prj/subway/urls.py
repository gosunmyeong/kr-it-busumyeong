from django.urls import path
from subway import views


urlpatterns = [
    path("", views.show_subway, name="show_subway"),
    path("show_statistics/", views.show_statistics, name="show_statistics"),
]