from django.contrib import admin
from subway.models import Subway
from subway.models import Amenities

# Register your models here.
@admin.register(Subway)
class SubwayAdmin(admin.ModelAdmin):
    pass

@admin.register(Amenities)
class AmenitiesAdmin(admin.ModelAdmin):
    pass