/*!
* Start Bootstrap - Freelancer v7.0.7 (https://startbootstrap.com/theme/freelancer)
* Copyright 2013-2023 Start Bootstrap
* Licensed under MIT (https://github.com/StartBootstrap/startbootstrap-freelancer/blob/master/LICENSE)
*/
//
// Scripts
// 

window.addEventListener('DOMContentLoaded', event => {

    // Navbar shrink function
    var navbarShrink = function () {
        const navbarCollapsible = document.body.querySelector('#mainNav');
        if (!navbarCollapsible) {
            return;
        }
        if (window.scrollY === 0) {
            navbarCollapsible.classList.remove('navbar-shrink')
        } else {
            navbarCollapsible.classList.add('navbar-shrink')
        }

    };

    // Shrink the navbar 
    navbarShrink();

    // Shrink the navbar when page is scrolled
    document.addEventListener('scroll', navbarShrink);

    // Activate Bootstrap scrollspy on the main nav element
    const mainNav = document.body.querySelector('#mainNav');
    if (mainNav) {
        new bootstrap.ScrollSpy(document.body, {
            target: '#mainNav',
            rootMargin: '0px 0px -40%',
        });
    };

    // Collapse responsive navbar when toggler is visible
    const navbarToggler = document.body.querySelector('.navbar-toggler');
    const responsiveNavItems = [].slice.call(
        document.querySelectorAll('#navbarResponsive .nav-link')
    );
    responsiveNavItems.map(function (responsiveNavItem) {
        responsiveNavItem.addEventListener('click', () => {
            if (window.getComputedStyle(navbarToggler).display !== 'none') {
                navbarToggler.click();
            }
        });
    });

});


// ELECT값 설정 START
// var subwaysData = {{ subways_json|safe }};
function changeSelectFunction(selected_value){
    var line1 = ["동대문", "동묘앞", "서울역", "시청", "신설동", "제기동", "종각", "종로3가", "종로5가", "청량리"];
	var line2 = ["강남", "강변", "건대입구", "교대", "구로디지털단지", "구의", "낙성대", "당산", "대림", "도림천", "동대문역사문화공원", "뚝섬", "문래", "방배", "봉천", "사당", "삼성", "상왕십리", "서울대입구", "서초", "선릉", "성수", "시청", "신답", "신당", "신대방", "신도림", "신림", "신설동", "신정네거리", "신촌", "아현", "양천구청", "역삼", "영등포구청", "왕십리", "용답", "용두", "을지로3가", "을지로4가", "을지로입구", "이대", "잠실", "잠실나루", "잠실새내", "종합운동장", "충정로", "한양대", "합정", "홍대입구"];
	var line3 = ["가락시장", "경복궁", "경찰병원", "고속터미널", "교대", "구파발", "금호", "남부터미널", "녹번", "대청", "대치", "도곡", "독립문", "동대입구", "매봉", "무악재", "불광", "수서", "신사", "안국", "압구정", "약수", "양재", "연신내", "오금", "옥수", "을지로3가", "일원", "잠원", "종로3가", "지축", "충무로", "학여울", "홍제"];
    var line4 = ["길음", "남태령", "노원", "당고개", "동대문", "동대문역사문화공원", "동작", "명동", "미아", "미아사거리", "사당", "삼각지", "상계", "서울역", "성신여대입구", "수유", "숙대입구", "신용산", "쌍문", "이촌", "창동", "총신대입구", "충무로", "한성대입구", "혜화", "회현"];
    var line5 = ["강동", "강일", "개롱", "개화산", "거여", "고덕", "공덕", "광나루", "광화문", "군자", "굽은다리", "길동", "김포공항", "까치산", "답십리", "동대문역사문화공원", "둔촌동", "마곡", "마장", "마천", "마포", "명일", "목동", "미사", "발산", "방이", "방화", "상일동", "서대문", "송정", "신금호", "신길", "신정", "아차산", "애오개", "양평", "여의나루", "여의도", "영등포구청", "영등포시장", "오금", "오목교", "올림픽공원", "왕십리", "우장산", "을지로4가", "장한평", "종로3가", "천호", "청구", "충정로", "하남검단산", "하남시청", "하남풍산", "행당", "화곡"];
    var line6 = ["고려대", "공덕", "광흥창", "구산", "녹사평", "대흥", "독바위", "돌곶이", "동묘앞", "디지털미디어시티", "마포구청", "망원", "버티고개", "보문", "봉화산", "불광", "삼각지", "상수", "상월곡", "새절", "석계", "신내", "신당", "안암", "약수", "역촌", "연신내", "월곡", "월드컵경기장", "응암", "이태원", "증산", "창신", "청구", "태릉입구", "한강진", "합정", "화랑대", "효창공원앞"];
    var line7 = ["가산디지털단지", "강남구청", "건대입구", "고속터미널", "공릉", "광명사거리", "군자", "남구로", "남성", "내방", "노원", "논현", "대림", "도봉산", "마들", "먹골", "면목", "반포", "보라매", "사가정", "상도", "상봉", "수락산", "숭실대입구", "신대방삼거리", "신풍", "어린이대공원", "온수", "용마산", "이수", "자양", "장승배기", "장암", "중계", "중곡", "중화", "천왕", "철산", "청담", "태릉입구", "하계", "학동"];
    var line8 = ["가락시장", "강동구청", "남위례", "남한산성입구", "단대오거리", "모란", "몽촌토성", "문정", "복정", "산성", "석촌", "송파", "수진", "신흥", "암사역사공원", "잠실", "장지", "천호"];
    var line9 = ["가양", "개화", "고속터미널", "공항시장", "구반포", "국회의사당", "김포공항", "노들", "노량진", "당산", "동작", "둔촌오륜", "등촌", "마곡나루", "봉은사", "사평", "삼성중앙", "삼전", "샛강", "석촌", "석촌고분", "선유도", "선정릉", "송파나루", "신논현", "신목동", "신반포", "신방화", "양천향교", "언주", "여의도", "염창", "올림픽공원", "종합운동장", "중앙보훈병원", "증미", "한성백제", "흑석"];

    var target = document.getElementById("select_station");
    if(selected_value == "line1"){
        var opt_station = line1;

    }else if(selected_value == "line2"){
        var opt_station = line2;

    }else if(selected_value == "line3"){
        var opt_station = line3;

    }else if(selected_value == "line4"){
        var opt_station = line4;

    }else if(selected_value == "line5"){
        var opt_station = line5;

    }else if(selected_value == "line6"){
        var opt_station = line6;

    }else if(selected_value == "line7"){
        var opt_station = line7;

    }else if(selected_value == "line8"){
        var opt_station = line8;

    }else if(selected_value == "line9"){
        var opt_station = line9;
    }
    target.options.length = 0;
    
    for (i in opt_station) {
		var opt = document.createElement("option");
		opt.value = opt_station[i];
		opt.innerHTML = opt_station[i];
		target.appendChild(opt);
	}
}
// SELECT값 설정 END

